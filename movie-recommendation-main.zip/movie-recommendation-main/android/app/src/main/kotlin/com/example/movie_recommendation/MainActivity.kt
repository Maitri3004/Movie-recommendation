package com.example.movie_recommendation

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
